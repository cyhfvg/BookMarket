module.exports = {
    // node端 配置项
    port: 8091,
    project_path: __dirname,
    // 后台api地址 配置项
    apiHost: "http://127.0.0.1",
    apiPort: 8080,
    apiModuleName: "bookMarket-java",
}
